var venueInfos = {
    "lax": {
        "airportCode": "lax",
        "assetVersion": "2016-05-04T22:01:11",
        "id": "lax",
        "name": "Los Angeles International Airport"
    },
    "sea": {
        "airportCode": "sea",
        "assetVersion": "2016-05-04T22:27:31",
        "id": "sea",
        "name": "Seattle-Tacoma International Airport"
    }
};

locuslabs.reduxStore.dispatch({ type: 'VENUE_LIST_LOADER/VENUE_LIST_LOADED_BY_SCRIPT', venueList: venueInfos });
